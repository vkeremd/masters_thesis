# train_model.py
import pandas as pd
import numpy as np
import evaluate
from datasets import Dataset
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          TrainingArguments, Trainer)
from sklearn.model_selection import train_test_split
import torch

print("Starting model training pipeline...")

# ---------- 1. Load + keep only the needed columns -------------------------
print("Loading training data...")
df = pd.read_csv("training_data_20250623_151949.csv")   # has text, label, etc.
print(f"Original dataset size: {len(df)} tweets")

df = df[["text", "label"]].dropna()
df["label"] = df["label"].astype(int)       # make sure it's 0/1

print(f"After cleaning: {len(df)} tweets")
print(f"Label distribution: {df['label'].value_counts().to_dict()}")

train_df, val_df = train_test_split(
    df, test_size=0.15, random_state=42, stratify=df["label"])

print(f"Training set: {len(train_df)} tweets")
print(f"Validation set: {len(val_df)} tweets")

train_ds = Dataset.from_pandas(train_df.reset_index(drop=True))
val_ds   = Dataset.from_pandas(val_df.reset_index(drop=True))

# ---------- 2. Tokenizer ---------------------------------------------------
print("Loading BERTweet tokenizer...")
tok = AutoTokenizer.from_pretrained("vinai/bertweet-base", use_fast=True)

def tokenize(batch):
    return tok(batch["text"],
               padding="max_length", 
               truncation=True,
               max_length=128)

print("Tokenizing datasets...")
train_ds = train_ds.map(tokenize, batched=True)
val_ds   = val_ds.map(tokenize,   batched=True)

# rename → 'labels' so HF Trainer picks it up automatically
train_ds = train_ds.rename_column("label", "labels")
val_ds   = val_ds.rename_column("label", "labels")

train_ds.set_format(type="torch",
                    columns=["input_ids", "attention_mask", "labels"])
val_ds.set_format("torch", columns=["input_ids", "attention_mask", "labels"])

# ---------- 3. Model -------------------------------------------------------
print("Loading BERTweet model...")
model = AutoModelForSequenceClassification.from_pretrained(
    "vinai/bertweet-base",
    num_labels=2)

# ---------- 4. Training args ----------------------------------------------
print("Setting up training configuration...")
args = TrainingArguments(
    output_dir="./bertweet_injustice",
    eval_strategy="epoch",  # Fixed: was evaluation_strategy
    save_strategy="epoch", 
    load_best_model_at_end=True,
    metric_for_best_model="f1",
    per_device_train_batch_size=16,
    per_device_eval_batch_size=32,
    num_train_epochs=4,
    learning_rate=2e-5,
    weight_decay=0.01,
    fp16=torch.cuda.is_available(),  # Use fp16 if GPU available
    seed=42,
    logging_steps=50,
    warmup_steps=100,
)

# ---------- 5. Metrics -----------------------------------------------------
print("Loading evaluation metrics...")
metric_f1 = evaluate.load("f1")

def compute_metrics(pred):
    logits, labels = pred
    preds = np.argmax(logits, axis=-1)
    return {"f1": metric_f1.compute(predictions=preds, references=labels)["f1"]}

# ---------- 6. Train -------------------------------------------------------
print("Starting training...")
print(f"Device: {'GPU' if torch.cuda.is_available() else 'CPU'}")

trainer = Trainer(model=model,
                  args=args,
                  train_dataset=train_ds,
                  eval_dataset=val_ds,
                  compute_metrics=compute_metrics)

# Train the model
trainer.train()

# Save the final model
print("Saving trained model...")
trainer.save_model("./bertweet_injustice_final")
tok.save_pretrained("./bertweet_injustice_final")

print("Training completed! Model saved to './bertweet_injustice_final'")

# ---------- 7. Evaluation --------------------------------------------------
print("Running final evaluation...")
eval_results = trainer.evaluate()
print(f"Final validation F1 score: {eval_results['eval_f1']:.4f}")
print(f"Final validation loss: {eval_results['eval_loss']:.4f}")

print("\nTraining pipeline completed successfully!") 