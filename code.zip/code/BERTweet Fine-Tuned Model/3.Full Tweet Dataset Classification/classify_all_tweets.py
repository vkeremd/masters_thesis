import json
import pandas as pd
import numpy as np
from datetime import datetime
from transformers import AutoTokenizer, AutoModelForSequenceClassification
import torch
from typing import List, Dict, Any
import csv
import time
import os

print("🚀 CLASSIFYING ALL TWEETS WITH TRAINED MODEL")
print("=" * 60)

# Load trained model and tokenizer
print("Loading trained BERTweet model...")
model_path = "./bertweet_injustice_final"
tokenizer = AutoTokenizer.from_pretrained(model_path)
model = AutoModelForSequenceClassification.from_pretrained(model_path)
model.eval()  # Set to evaluation mode

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model.to(device)
print(f"Model loaded on device: {device}")

def classify_tweets_batch(tweets: List[str], batch_size: int = 32) -> List[int]:
    """Classify tweets in batches for efficiency"""
    predictions = []
    
    for i in range(0, len(tweets), batch_size):
        batch_tweets = tweets[i:i + batch_size]
        
        # Tokenize batch
        inputs = tokenizer(
            batch_tweets,
            padding=True,
            truncation=True,
            max_length=128,
            return_tensors='pt'
        ).to(device)
        
        # Get predictions
        with torch.no_grad():
            outputs = model(**inputs)
            batch_predictions = torch.argmax(outputs.logits, dim=-1).cpu().numpy()
            predictions.extend(batch_predictions)
    
    return predictions

def extract_location_data(tweet_data: Dict) -> Dict:
    """Extract location information from tweet"""
    location_info = {
        'coordinates': None,
        'place_name': None,
        'user_location': None
    }
    
    # Check for coordinates
    if tweet_data.get('coordinates'):
        coords = tweet_data['coordinates']
        if coords.get('coordinates'):
            location_info['coordinates'] = coords['coordinates']  # [lng, lat]
    
    # Check for place information
    if tweet_data.get('place'):
        place = tweet_data['place']
        location_info['place_name'] = place.get('full_name')
    
    # Check user location (less reliable but sometimes useful)
    if tweet_data.get('user') and tweet_data['user'].get('location'):
        location_info['user_location'] = tweet_data['user']['location']
    
    return location_info

def process_tweet_file(file_path: str, output_writer: csv.DictWriter, processed_count: int) -> int:
    """Process a single tweet file"""
    print(f"\nProcessing {file_path}...")
    
    tweet_batch = []
    tweet_data_batch = []
    batch_size = 100
    file_processed = 0
    
    with open(file_path, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            try:
                line_data = json.loads(line.strip())
                
                # Handle both single tweets and data arrays
                tweets_in_line = []
                if isinstance(line_data, dict) and 'data' in line_data:
                    tweets_in_line = line_data['data']
                elif isinstance(line_data, dict) and 'text' in line_data:
                    tweets_in_line = [line_data]
                
                for tweet_data in tweets_in_line:
                    if not isinstance(tweet_data, dict) or 'text' not in tweet_data:
                        continue
                    
                    tweet_text = tweet_data.get('text', '').strip()
                    if not tweet_text:
                        continue
                    
                    tweet_batch.append(tweet_text)
                    tweet_data_batch.append(tweet_data)
                    
                    # Process batch when full
                    if len(tweet_batch) >= batch_size:
                        predictions = classify_tweets_batch(tweet_batch)
                        
                        # Write results
                        for i, (tweet_text, tweet_info, prediction) in enumerate(zip(tweet_batch, tweet_data_batch, predictions)):
                            # Extract date
                            created_at = tweet_info.get('created_at', '')
                            date = created_at.split('T')[0] if 'T' in created_at else ''
                            
                            # Extract location
                            location_info = extract_location_data(tweet_info)
                            
                            # Write row
                            output_writer.writerow({
                                'tweet_id': tweet_info.get('id', f'unknown_{processed_count + file_processed + i}'),
                                'text': tweet_text,
                                'date': date,
                                'injustice_label': prediction,
                                'coordinates': json.dumps(location_info['coordinates']) if location_info['coordinates'] else '',
                                'place_name': location_info['place_name'] or '',
                                'user_location': location_info['user_location'] or '',
                                'created_at': created_at
                            })
                        
                        file_processed += len(tweet_batch)
                        tweet_batch = []
                        tweet_data_batch = []
                        
                        # Progress update
                        if file_processed % 10000 == 0:
                            print(f"  Processed {file_processed:,} tweets from {file_path}")
            
            except Exception as e:
                if line_num % 1000 == 0:  # Only print occasional errors
                    print(f"  Error processing line {line_num}: {e}")
                continue
        
        # Process remaining tweets
        if tweet_batch:
            predictions = classify_tweets_batch(tweet_batch)
            for i, (tweet_text, tweet_info, prediction) in enumerate(zip(tweet_batch, tweet_data_batch, predictions)):
                created_at = tweet_info.get('created_at', '')
                date = created_at.split('T')[0] if 'T' in created_at else ''
                location_info = extract_location_data(tweet_info)
                
                output_writer.writerow({
                    'tweet_id': tweet_info.get('id', f'unknown_{processed_count + file_processed + i}'),
                    'text': tweet_text,
                    'date': date,
                    'injustice_label': prediction,
                    'coordinates': json.dumps(location_info['coordinates']) if location_info['coordinates'] else '',
                    'place_name': location_info['place_name'] or '',
                    'user_location': location_info['user_location'] or '',
                    'created_at': created_at
                })
            
            file_processed += len(tweet_batch)
    
    print(f"  Completed {file_path}: {file_processed:,} tweets processed")
    return file_processed

def main():
    # File paths
    file_paths = [
        'tweets-0525-0615-nort',
        'tweets-0525-0615-2-nort',
        'tweets-0525-0615-3-nort',
        'tweets-0525-0615-4-nort',
        'tweets-0525-0615-5-nort'
    ]
    
    # Check for existing partial results
    import glob
    existing_files = glob.glob('all_tweets_classified_*.csv')
    
    if existing_files:
        print("🔄 RESUMABLE PROCESSING DETECTED")
        print(f"Found existing file: {existing_files[-1]}")
        
        # Check which files have been processed
        progress_file = 'classification_progress.txt'
        completed_files = []
        if os.path.exists(progress_file):
            with open(progress_file, 'r') as f:
                completed_files = [line.strip() for line in f.readlines()]
        
        remaining_files = [f for f in file_paths if f not in completed_files]
        
        print(f"Completed files: {len(completed_files)}/{len(file_paths)}")
        if remaining_files:
            print(f"Remaining files: {remaining_files}")
            resume = input("Resume processing? (y/n): ").lower().strip()
            if resume == 'y':
                file_paths = remaining_files
                output_filename = existing_files[-1]
            else:
                output_filename = f'all_tweets_classified_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
        else:
            print("✅ All files already processed!")
            return
    else:
        output_filename = f'all_tweets_classified_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    
    print(f"Output file: {output_filename}")
    print(f"Files to process: {len(file_paths)}")
    print(f"Estimated time per file: ~45-60 minutes")
    print(f"Total estimated time: {len(file_paths) * 50 / 60:.1f} hours\n")
    
    # Confirm with user
    confirm = input("Continue with classification? (y/n): ").lower().strip()
    if confirm != 'y':
        print("Operation cancelled.")
        return
    
    start_time = time.time()
    total_processed = 0
    
    # Open output file (append mode if resuming)
    file_mode = 'a' if os.path.exists(output_filename) else 'w'
    write_header = not os.path.exists(output_filename)
    
    with open(output_filename, file_mode, newline='', encoding='utf-8') as f:
        fieldnames = ['tweet_id', 'text', 'date', 'injustice_label', 'coordinates', 'place_name', 'user_location', 'created_at']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        
        if write_header:
            writer.writeheader()
        
        # Process each file
        for i, file_path in enumerate(file_paths, 1):
            print(f"\n{'='*20} FILE {i}/{len(file_paths)} {'='*20}")
            file_processed = process_tweet_file(file_path, writer, total_processed)
            total_processed += file_processed
            
            # Save progress
            with open('classification_progress.txt', 'a') as progress_f:
                progress_f.write(f"{file_path}\n")
            
            print(f"✅ {file_path} completed and progress saved!")
            
            # Progress summary
            elapsed = time.time() - start_time
            rate = total_processed / elapsed if elapsed > 0 else 0
            eta = (10800000 - total_processed) / rate if rate > 0 else 0
            
            print(f"\n📊 PROGRESS SUMMARY:")
            print(f"  Total processed: {total_processed:,}")
            print(f"  Rate: {rate:.1f} tweets/second")
            print(f"  Elapsed: {elapsed/60:.1f} minutes")
            print(f"  ETA: {eta/60:.1f} minutes remaining")
    
    # Final summary
    elapsed = time.time() - start_time
    injustice_count = 0  # Would need to calculate from file
    
    print(f"\n✅ CLASSIFICATION COMPLETE!")
    print(f"=" * 60)
    print(f"📊 Total tweets processed: {total_processed:,}")
    print(f"⏱️  Total time: {elapsed/60:.1f} minutes")
    print(f"📁 Output file: {output_filename}")
    print(f"🎯 Ready for geographic analysis!")

if __name__ == "__main__":
    main() 