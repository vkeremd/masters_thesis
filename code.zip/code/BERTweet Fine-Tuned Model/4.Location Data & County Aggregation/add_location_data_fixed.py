#!/usr/bin/env python3
"""
Add Location Data to Classified Tweets (Fixed Version)
Properly handles the JSON structure of tweet files to extract location data and map to counties.
"""

import json
import pandas as pd
import numpy as np
from collections import defaultdict
import time
from datetime import datetime
import os
import sys
from typing import Dict, List, Tuple, Optional

def log_message(message: str):
    """Log message with timestamp"""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[{timestamp}] {message}")
    sys.stdout.flush()

def extract_location_from_place(place_data):
    """Extract location information from place data"""
    if not place_data or not isinstance(place_data, dict):
        return None, None, None, None
    
    # Extract coordinates from bounding box
    coordinates = None
    if 'geo' in place_data and place_data['geo']:
        geo = place_data['geo']
        if 'bbox' in geo and geo['bbox']:
            bbox = geo['bbox']
            # Calculate center point of bounding box
            lats = [bbox[1], bbox[3]]  # min_lat, max_lat
            lons = [bbox[0], bbox[2]]  # min_lon, max_lon
            coordinates = f"{np.mean(lons):.6f},{np.mean(lats):.6f}"
    
    # Extract place name
    place_name = place_data.get('full_name', None)
    
    # Extract country info
    country = None
    if place_name:
        parts = place_name.split(', ')
        if len(parts) > 1:
            country = parts[-1]
    
    return coordinates, place_name, country, place_data.get('id')

def load_county_mapping():
    """Load county mapping from geocoded places"""
    log_message("Loading county mapping data...")
    
    try:
        places_df = pd.read_csv('places_geocoded.csv')
        
        # Create mapping from geo_name to county info
        county_mapping = {}
        usable_mappings = 0
        
        for _, row in places_df.iterrows():
            geo_name = row.get('geo_name', '')
            fips = row.get('fips', '')
            state_abb = row.get('state_abb', '')
            
            if pd.notna(fips) and pd.notna(geo_name) and str(fips).strip() != '':
                try:
                    county_mapping[geo_name.lower()] = {
                        'fips_code': str(int(fips)),
                        'county_name': geo_name,
                        'state_name': state_abb
                    }
                    usable_mappings += 1
                except (ValueError, TypeError):
                    continue
        
        log_message(f"Loaded {len(county_mapping)} place mappings with {usable_mappings} usable FIPS codes")
        return county_mapping
        
    except Exception as e:
        log_message(f"Error loading county mapping: {e}")
        return {}

def process_tweet_file(filename: str, location_dict: Dict, county_mapping: Dict):
    """Process a single tweet file to extract location data"""
    log_message(f"Processing {filename}...")
    
    tweets_processed = 0
    tweets_with_location = 0
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line_num, line in enumerate(f, 1):
                if line_num % 10000 == 0:
                    log_message(f"  Processed {line_num:,} lines...")
                
                try:
                    data = json.loads(line.strip())
                    
                    # Extract places array from includes
                    places = data.get('includes', {}).get('places', [])
                    places_dict = {place['id']: place for place in places if 'id' in place}
                    
                    # Process tweets array
                    tweets = data.get('data', [])
                    for tweet in tweets:
                        tweets_processed += 1
                        
                        tweet_id = tweet.get('id')
                        if not tweet_id:
                            continue
                        
                        # Check for geo information in tweet
                        geo_info = tweet.get('geo', {})
                        place_id = geo_info.get('place_id') if geo_info else None
                        
                        if place_id and place_id in places_dict:
                            place_data = places_dict[place_id]
                            coordinates, place_name, country, _ = extract_location_from_place(place_data)
                            
                            if place_name:
                                tweets_with_location += 1
                                
                                # Add to location dictionary
                                location_dict[tweet_id] = {
                                    'coordinates': coordinates,
                                    'place_name': place_name,
                                    'country': country,
                                    'place_id': place_id
                                }
                
                except json.JSONDecodeError:
                    continue
                except Exception as e:
                    log_message(f"Error processing line {line_num}: {e}")
                    continue
    
    except Exception as e:
        log_message(f"Error reading file {filename}: {e}")
    
    log_message(f"Completed {filename}: {tweets_processed:,} tweets processed, {tweets_with_location:,} with location")
    return tweets_processed, tweets_with_location

def map_to_counties(location_dict: Dict, county_mapping: Dict):
    """Map location data to counties"""
    log_message("Mapping locations to counties...")
    
    county_matches = 0
    
    for tweet_id, location_data in location_dict.items():
        place_name = location_data.get('place_name', '')
        if place_name:
            # Try exact match first
            if place_name.lower() in county_mapping:
                location_data['fips_code'] = county_mapping[place_name.lower()]['fips_code']
                location_data['county_name'] = county_mapping[place_name.lower()]['county_name']
                location_data['state_name'] = county_mapping[place_name.lower()]['state_name']
                county_matches += 1
            else:
                # Try partial matching
                for mapped_place, county_info in county_mapping.items():
                    if mapped_place in place_name.lower() or place_name.lower() in mapped_place:
                        location_data['fips_code'] = county_info['fips_code']
                        location_data['county_name'] = county_info['county_name']
                        location_data['state_name'] = county_info['state_name']
                        county_matches += 1
                        break
    
    log_message(f"Mapped {county_matches:,} tweets to counties")
    return county_matches

def main():
    """Main processing function"""
    start_time = time.time()
    log_message("Starting location data extraction for classified tweets...")
    
    # Load county mapping
    county_mapping = load_county_mapping()
    
    # Load classified tweets
    log_message("Loading classified tweets from all_tweets_classified_20250627_120357.csv...")
    try:
        df = pd.read_csv('all_tweets_classified_20250627_120357.csv')
        log_message(f"Loaded {len(df):,} classified tweets")
    except Exception as e:
        log_message(f"Error loading classified tweets: {e}")
        return
    
    # Prepare location dictionary
    log_message(f"Prepared location dictionary for {len(df):,} tweets")
    location_dict = {}
    
    # Process tweet files
    tweet_files = [
        'tweets-0525-0615-nort',
        'tweets-0525-0615-2-nort', 
        'tweets-0525-0615-3-nort',
        'tweets-0525-0615-4-nort',
        'tweets-0525-0615-5-nort'
    ]
    
    total_tweets_processed = 0
    total_tweets_with_location = 0
    
    for filename in tweet_files:
        if os.path.exists(filename):
            tweets_processed, tweets_with_location = process_tweet_file(filename, location_dict, county_mapping)
            total_tweets_processed += tweets_processed
            total_tweets_with_location += tweets_with_location
        else:
            log_message(f"File {filename} not found, skipping...")
    
    # Map to counties
    county_matches = map_to_counties(location_dict, county_mapping)
    
    # Add location data to dataframe
    log_message("Adding location data to dataframe...")
    
    df['coordinates'] = df['tweet_id'].map(lambda x: location_dict.get(str(x), {}).get('coordinates'))
    df['place_name'] = df['tweet_id'].map(lambda x: location_dict.get(str(x), {}).get('place_name'))
    df['country'] = df['tweet_id'].map(lambda x: location_dict.get(str(x), {}).get('country'))
    df['fips_code'] = df['tweet_id'].map(lambda x: location_dict.get(str(x), {}).get('fips_code'))
    df['county_name'] = df['tweet_id'].map(lambda x: location_dict.get(str(x), {}).get('county_name'))
    df['state_name'] = df['tweet_id'].map(lambda x: location_dict.get(str(x), {}).get('state_name'))
    
    # Print summary
    log_message("\n📊 Location Data Summary:")
    log_message(f"Total tweets: {len(df):,}")
    log_message(f"Tweets with coordinates: {df['coordinates'].notna().sum():,} ({df['coordinates'].notna().sum()/len(df)*100:.1f}%)")
    log_message(f"Tweets with place names: {df['place_name'].notna().sum():,} ({df['place_name'].notna().sum()/len(df)*100:.1f}%)")
    log_message(f"Tweets with country info: {df['country'].notna().sum():,} ({df['country'].notna().sum()/len(df)*100:.1f}%)")
    log_message(f"Tweets mapped to counties: {df['fips_code'].notna().sum():,} ({df['fips_code'].notna().sum()/len(df)*100:.1f}%)")
    
    # Save enriched dataset
    output_filename = 'tweets_with_locations_fixed.csv'
    df.to_csv(output_filename, index=False)
    log_message(f"\n✅ Analysis completed in {(time.time() - start_time)/60:.1f} minutes")
    log_message(f"📁 Enriched dataset: {output_filename}")
    
    # Create county-level aggregation
    log_message("\n🗺️ Creating county-level aggregation...")
    
    # Filter tweets with county data
    county_df = df[df['fips_code'].notna()].copy()
    log_message(f"Tweets with county data: {len(county_df):,}")
    
    if len(county_df) > 0:
        # Convert date to datetime
        county_df['date'] = pd.to_datetime(county_df['date'])
        
        # Create daily county aggregation
        county_agg = county_df.groupby(['fips_code', 'county_name', 'state_name', 'date', 'injustice_label']).size().reset_index(name='tweet_count')
        
        # Save county aggregation
        county_filename = 'blm_tweets_by_county.csv'
        county_agg.to_csv(county_filename, index=False)
        log_message(f"📊 County-level aggregation: {county_filename}")
        
        # Print county summary
        unique_counties = county_df['fips_code'].nunique()
        log_message(f"📊 Unique counties with data: {unique_counties:,}")
        
        # Show top counties by tweet volume
        top_counties = county_df.groupby(['county_name', 'state_name']).size().sort_values(ascending=False).head(10)
        log_message("\n🏆 Top 10 counties by tweet volume:")
        for (county, state), count in top_counties.items():
            log_message(f"  {county}, {state}: {count:,} tweets")
    
    log_message(f"\n📊 Total tweets processed: {total_tweets_processed:,}")
    log_message(f"📊 Tweets with location: {total_tweets_with_location:,}")

if __name__ == "__main__":
    main() 