import json
from datetime import datetime
import random
import pandas as pd
from openai import OpenAI
import csv
from typing import List, Dict, Any
import os
import time
import numpy as np
import evaluate
from datasets import Dataset
from transformers import (AutoTokenizer, AutoModelForSequenceClassification,
                          TrainingArguments, Trainer)
from sklearn.model_selection import train_test_split

# Configure OpenAI API with new client
#api key removed for securtiy reasons
#client = OpenAI(api_key="")

# FIXED: Complete system prompt with examples and edge cases
SYSTEM_PROMPT = """You are an expert social media analyst/psychologist specializing in detecting expressions of perceived injustice in tweets.

Label exactly one of:
  YES  – The tweet expresses outrage, indignation, resentment, or complaint
         about a situation framed as UNFAIR or UNJUST to a person or group.
  NO   – Anything else (general negativity, personal anger, sadness, humour,
         policy discussion without an injustice frame, ads, blank/URL-only).

Decision rules:
Count as YES when the text:
  • Asserts unequal or biased treatment, exploitation, unfairness, oppression,
    or rigged rules/outcomes.
  • Uses injustice cues: "unfair", "so unjust", "we're being screwed",
    "they always get away with", "perpetrators not punished", "system is rigged", "privileged", "this system exploits the blacks"...
  • Voices anger/resentment toward advantaged people or institutions
  • Calls for support of the disadvantaged: "support for Black owned businesses", "call to action for legal support for the disadvantaged, the black, the hispanics etc."

Count as NO when the text:
  • Is merely negative ("I hate Mondays"), complains about personal
    inconvenience without an unfairness frame ("train is late").
  • Expresses policy preference or factual statement without resentment
    ("We need higher taxes on the rich").
  • Contains the word "justice" in a neutral context
    ("Justice Department released a report").
  • Is satire or quotes song lyrics without endorsing the injustice idea.

Edge cases:
  • Sarcasm about injustice ⇒ YES if the target is still injustice
    ("Sure, pay cuts for nurses while CEOs get bonuses – makes total sense 🙄").
  • Hashtags alone (#JusticeForX) ⇒ YES only if context clearly implies
    injustice; otherwise NO.

Examples:
1. "Another young Black man shot and no one will be held accountable. WHEN WILL THIS SYSTEM CHANGE?!" → YES
2. "Enough is enough when will black lives actually matter!!" → YES
3. "My internet is down again. So annoying." → NO
4. "Imagine thinking billionaires deserve tax breaks while kids go hungry." → YES
5. "#JusticeForWhales 🐳" (no other text) → NO
6. "They fired me after I reported safety issues. Totally unfair!" → YES
7. "I support raising the minimum wage." → NO
8. "Fair distribution of resources. NOW!" → YES
9. "Vigil held for George Floyd" → YES
10. "Police extra-judicially killing of unarmed man" → YES
11. "DA addresses vigil for George Floyd killed by police" → YES
12. "BLM protest in downtown. We stand united!" → YES
13. "BLM protests blocked the highway again—sick of activists disrupting ordinary people's commute for attention." → NO
14. "Brings tears to my eyes. I'm so proud of my people. We are not going to be silenced." → YES

Respond with ONLY: YES or NO"""

def load_all_tweets_randomly(file_paths: List[str], sample_size: int = 2000) -> List[Dict]:
    """Load tweets with true random sampling across all files."""
    all_tweets = []
    
    # First pass: count total tweets and get file sizes
    print("Scanning files to get tweet counts...")
    file_info = []
    total_tweets = 0
    
    for file_path in file_paths:
        try:
            tweet_count = 0
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        tweet_data = json.loads(line)
                        if 'data' in tweet_data:
                            tweet_count += len(tweet_data['data'])
                        elif 'id' in tweet_data and 'created_at' in tweet_data:
                            tweet_count += 1
                    except json.JSONDecodeError:
                        continue
            
            file_info.append({
                'path': file_path,
                'tweet_count': tweet_count
            })
            total_tweets += tweet_count
            print(f"  {file_path}: {tweet_count:,} tweets")
            
        except Exception as e:
            print(f"Error scanning {file_path}: {str(e)}")
    
    print(f"Total tweets across all files: {total_tweets:,}")
    
    # Calculate how many tweets to sample from each file proportionally
    tweets_to_sample = []
    for file_info_item in file_info:
        file_path = file_info_item['path']
        file_tweet_count = file_info_item['tweet_count']
            
        # Calculate proportional sample size for this file
        file_sample_size = max(1, int((file_tweet_count / total_tweets) * sample_size))
        
        print(f"Sampling {file_sample_size:,} tweets from {file_path}...")
        
        # Load all tweets from this file
        file_tweets = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        tweet_data = json.loads(line)
                        if 'data' in tweet_data:
                            file_tweets.extend(tweet_data['data'])
                        elif 'id' in tweet_data and 'created_at' in tweet_data:
                            file_tweets.append(tweet_data)
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            print(f"Error reading {file_path}: {str(e)}")
            continue
        
        # Randomly sample from this file
        if len(file_tweets) > file_sample_size:
            sampled_tweets = random.sample(file_tweets, file_sample_size)
        else:
            sampled_tweets = file_tweets
                
        tweets_to_sample.extend(sampled_tweets)
        print(f"  Added {len(sampled_tweets):,} tweets from {file_path}")
    
    # Final random shuffle to ensure true randomness
    random.shuffle(tweets_to_sample)
    
    # Take the final sample
    if len(tweets_to_sample) > sample_size:
        final_sample = random.sample(tweets_to_sample, sample_size)
    else:
        final_sample = tweets_to_sample
    
    print(f"Final sample size: {len(final_sample):,}")
    return final_sample

def classify_tweet_with_gpt(tweet_text: str) -> str:
    """Classify a single tweet using GPT-4."""
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            temperature=0.1,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Tweet: {tweet_text}"}
            ],
            max_tokens=10
        )
        
        classification = response.choices[0].message.content.strip().upper()
        
        # Validate response
        if classification not in ['YES', 'NO']:
            print(f"Warning: Invalid classification '{classification}', defaulting to NO")
            classification = 'NO'
        
        return classification
        
    except Exception as e:
        print(f"Error classifying tweet: {e}")
        return 'NO'

def save_progress(results: List[Dict], batch_num: int):
    """Save progress to a backup file"""
    backup_filename = f'training_data_backup_batch_{batch_num}.csv'
    with open(backup_filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['tweet_id', 'text', 'label', 'classification'])
        writer.writeheader()
        writer.writerows(results)
    print(f"Progress saved to {backup_filename}")

def main():
    print("🚀 CREATING TRAINING DATASET - 2000 TWEETS")
    print("=" * 60)
    
    # File paths
    file_paths = [
        'tweets-0525-0615-nort',
        'tweets-0525-0615-2-nort',
        'tweets-0525-0615-3-nort',
        'tweets-0525-0615-4-nort',
        'tweets-0525-0615-5-nort'
    ]
    
    # Load sample tweets
    print("1. Loading tweets with proportional random sampling...")
    sample_tweets = load_all_tweets_randomly(file_paths, sample_size=2000)
    print(f"Loaded {len(sample_tweets):,} tweets for classification\n")
    
    if len(sample_tweets) == 0:
        print("❌ No tweets loaded. Exiting.")
        return
    
    # Estimate cost
    estimated_cost = len(sample_tweets) * 0.001  # Rough estimate
    print(f"💰 Estimated cost: ~${estimated_cost:.2f}")
    print(f"⏱️  Estimated time: ~{len(sample_tweets) * 0.6 / 60:.1f} minutes\n")
    
    # Confirm with user
    confirm = input("Continue? (y/n): ").lower().strip()
    if confirm != 'y':
        print("Operation cancelled.")
        return
    
    # Classify tweets with progress tracking
    print("2. Classifying tweets with GPT-4o-mini...")
    results = []
    start_time = time.time()
    
    for i, tweet in enumerate(sample_tweets, 1):
        tweet_text = tweet.get('text', '').strip()
        if not tweet_text:
            print(f"  Skipping tweet {i} - no text content")
            continue
            
        # Progress indicator
        if i % 50 == 0 or i == 1:
            elapsed = time.time() - start_time
            rate = i / elapsed if elapsed > 0 else 0
            eta = (len(sample_tweets) - i) / rate if rate > 0 else 0
            print(f"  Progress: {i:,}/{len(sample_tweets):,} ({i/len(sample_tweets)*100:.1f}%) - Rate: {rate:.1f}/min - ETA: {eta/60:.1f}min")
        
        classification = classify_tweet_with_gpt(tweet_text)
        
        results.append({
            'tweet_id': tweet.get('id', f'train_{i}'),
            'text': tweet_text,
            'label': 1 if classification == 'YES' else 0,
            'classification': classification
        })
        
        # Save progress every 200 tweets
        if i % 200 == 0:
            save_progress(results, i // 200)
        
        # Rate limiting - small delay
        time.sleep(0.6)  # Slightly longer delay for large batch
    
    # Save final results
    print(f"\n3. Saving final training dataset...")
    
    # Save as CSV
    csv_filename = f'training_data_{datetime.now().strftime("%Y%m%d_%H%M%S")}.csv'
    with open(csv_filename, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=['tweet_id', 'text', 'label', 'classification'])
        writer.writeheader()
        writer.writerows(results)
    
    # Save as JSON for flexibility
    json_filename = f'training_data_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
    with open(json_filename, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    # Calculate statistics
    yes_count = sum(1 for r in results if r['classification'] == 'YES')
    no_count = sum(1 for r in results if r['classification'] == 'NO')
    actual_cost = len(results) * 0.001  # Rough estimate
    
    # Final summary
    print(f"\n✅ TRAINING DATASET COMPLETE!")
    print(f"=" * 60)
    print(f"📊 Total tweets classified: {len(results):,}")
    print(f"📈 YES (injustice): {yes_count:,} ({yes_count/len(results)*100:.1f}%)")
    print(f"📉 NO (no injustice): {no_count:,} ({no_count/len(results)*100:.1f}%)")
    print(f"💰 Estimated cost: ~${actual_cost:.2f}")
    print(f"⏱️  Total time: {(time.time() - start_time)/60:.1f} minutes")
    print(f"📁 Files saved:")
    print(f"   - {csv_filename}")
    print(f"   - {json_filename}")
    print(f"\n🎯 Ready for model training!")

if __name__ == "__main__":
    main()
