#!/usr/bin/env python3
"""
Test script for BLM classification criteria
Use this to test your modifications before running the full analysis
"""

def is_pro_blm_test(text):
    """Test version - modify this with your new criteria"""
    
    # YOUR MODIFIED CRITERIA HERE
    pro_indicators = [
        "black lives matter", "blm", "justice for", "say their names",
        "defund the police", "abolish the police", "systemic racism",
        "police brutality", "racial justice", "protest", "march",
        "solidarity", "stand with", "support blm"
    ]
    
    anti_indicators = [
        "all lives matter", "blue lives matter", "riots", "looters",
        "thugs", "criminals", "antifa", "violent protests",
        "law and order", "back the blue"
    ]
    
    text_lower = text.lower()
    pro_score = sum(1 for indicator in pro_indicators if indicator in text_lower)
    anti_score = sum(1 for indicator in anti_indicators if indicator in text_lower)
    
    return pro_score > anti_score

# Test cases
test_tweets = [
    "Black Lives Matter and we need justice for George Floyd",
    "All lives matter, not just black lives",
    "I support peaceful protests for racial justice", 
    "These riots need to stop, law and order!",
    "BLM is important for our community",
    "Back the blue, support our police officers"
]

print("🧪 Testing BLM Classification Criteria\n")
print("Tweet → Classification")
print("-" * 50)

for tweet in test_tweets:
    classification = "PRO-BLM" if is_pro_blm_test(tweet) else "ANTI-BLM"
    print(f"{tweet[:40]}... → {classification}")

print(f"\n✅ Test complete! Modify criteria in is_pro_blm_test() and re-run.") 