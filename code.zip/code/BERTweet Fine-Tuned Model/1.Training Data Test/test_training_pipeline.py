import json
from datetime import datetime
import random
import pandas as pd
import openai
import csv
from typing import List, Dict, Any
import os

# Configure OpenAI API
#removed for security purposes
#openai.api_key = ""

def load_all_tweets_randomly(file_paths: List[str], sample_size: int = 10) -> List[Dict]:
    """Load tweets with true random sampling across all files."""
    all_tweets = []
    
    # First pass: count total tweets and get file sizes
    print("Scanning files to get tweet counts...")
    file_info = []
    total_tweets = 0
    
    for file_path in file_paths:
        try:
            tweet_count = 0
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        tweet_data = json.loads(line)
                        if 'data' in tweet_data:
                            tweet_count += len(tweet_data['data'])
                        elif 'id' in tweet_data and 'created_at' in tweet_data:
                            tweet_count += 1
                    except json.JSONDecodeError:
                        continue
            
            file_info.append({
                'path': file_path,
                'tweet_count': tweet_count
            })
            total_tweets += tweet_count
            print(f"  {file_path}: {tweet_count} tweets")
            
        except Exception as e:
            print(f"Error scanning {file_path}: {str(e)}")
    
    print(f"Total tweets across all files: {total_tweets}")
    
    # Calculate how many tweets to sample from each file proportionally
    tweets_to_sample = []
    for file_info_item in file_info:
        file_path = file_info_item['path']
        file_tweet_count = file_info_item['tweet_count']
        
        # Calculate proportional sample size for this file
        file_sample_size = max(1, int((file_tweet_count / total_tweets) * sample_size))
        
        print(f"Sampling {file_sample_size} tweets from {file_path}...")
        
        # Load all tweets from this file
        file_tweets = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                        
                    try:
                        tweet_data = json.loads(line)
                        if 'data' in tweet_data:
                            file_tweets.extend(tweet_data['data'])
                        elif 'id' in tweet_data and 'created_at' in tweet_data:
                            file_tweets.append(tweet_data)
                    except json.JSONDecodeError:
                        continue
        except Exception as e:
            print(f"Error reading {file_path}: {str(e)}")
            continue
        
        # Randomly sample from this file
        if len(file_tweets) > file_sample_size:
            sampled_tweets = random.sample(file_tweets, file_sample_size)
        else:
            sampled_tweets = file_tweets
        
        tweets_to_sample.extend(sampled_tweets)
    
    # Final random shuffle to ensure true randomness
    random.shuffle(tweets_to_sample)
    
    # Take the final sample
    if len(tweets_to_sample) > sample_size:
        final_sample = random.sample(tweets_to_sample, sample_size)
    else:
        final_sample = tweets_to_sample
    
    print(f"Final sample size: {len(final_sample)}")
    return final_sample

def classify_tweet_with_gpt(tweet_text: str) -> Dict[str, Any]:
    """Classify a single tweet using GPT-4."""
    
    prompt = f"""
    You are an expert coder classifying tweets for injustice detection. Analyze the following tweet and classify it as YES or NO.

    Label exactly one of:
      YES  – The tweet expresses outrage, indignation, resentment, or complaint
             about a situation framed as UNFAIR or UNJUST to a person or group.
      NO   – Anything else (general negativity, personal anger, sadness, humour,
             policy discussion without an injustice frame, ads, blank/URL-only).

    Decision rules:
    Count as YES when the text...
      • Asserts unequal or biased treatment, exploitation, oppression,
        or rigged rules/outcomes.
      • Uses injustice cues: "unfair", "so unjust", "we're being screwed",
        "they always get away with", "system is rigged", "privileged", "this system exploits the blacks"...
      • Voices anger/resentment toward advantaged people or institutions.

    Count as NO when the text...
      • Is merely negative ("I hate Mondays"), complains about personal
        inconvenience without an unfairness frame ("train is late").
      • Expresses policy preference or factual statement without resentment
        ("We need higher taxes on the rich").
      • Contains the word "justice" in a neutral context
        ("Justice Department released a report").
      • Is satire or quotes song lyrics without endorsing the injustice idea.

    Edge cases:
      • Sarcasm about injustice ⇒ YES if the target is still injustice
        ("Sure, pay cuts for nurses while CEOs get bonuses – makes total sense 🙄").
      • Hashtags alone (#JusticeForX) ⇒ YES only if context clearly implies
        injustice; otherwise NO.

    Examples:
    1. "Another young Black man shot and no one will be held accountable. WHEN WILL THIS SYSTEM CHANGE?!" → YES
    2. "Enough is enough when will black lives actually matter!!" → YES
    3. "My internet is down again. So annoying." → NO
    4. "Imagine thinking billionaires deserve tax breaks while kids go hungry." → YES
    5. "#JusticeForWhales 🐳" (no other text) → NO
    6. "They fired me after I reported safety issues. Totally unfair!" → YES
    7. "I support raising the minimum wage." → NO
    8. "Fair distribution of resources. NOW!" → YES

    Tweet to classify: "{tweet_text}"

    Respond with a JSON object containing:
    {{
        "classification": "YES" or "NO",
        "confidence": 0.0-1.0,
        "reasoning": "brief explanation of why this classification was chosen"
    }}

    Only respond with valid JSON.
    """
    
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4-turbo-preview",
            messages=[
                {"role": "system", "content": "You are an expert social media analyst specializing in detecting expressions of perceived injustice. You follow classification guidelines precisely and provide consistent, accurate classifications."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.1,
            max_tokens=200
        )
        
        result_text = response.choices[0].message.content.strip()
        
        try:
            result = json.loads(result_text)
            return {
                'label': 1 if result.get('classification', 'NO') == 'YES' else 0,
                'confidence': result.get('confidence', 0.0),
                'reasoning': result.get('reasoning', '')
            }
        except json.JSONDecodeError:
            return {
                'label': 1 if 'yes' in result_text.lower() else 0,
                'confidence': 0.5,
                'reasoning': 'LLM response parsing failed'
            }
            
    except Exception as e:
        print(f"Error calling LLM API: {str(e)}")
        return {
            'label': 0,
            'confidence': 0.0,
            'reasoning': f'API error: {str(e)}'
        }

def test_pipeline():
    """Test the entire pipeline with truly random sampling."""
    
    # File paths
    file_paths = [
        "tweets-0525-0615-nort",
        "tweets-0525-0615-2-nort",
        "tweets-0525-0615-3-nort",
        "tweets-0525-0615-4-nort",
        "tweets-0525-0615-5-nort"
    ]
    
    print("🧪 TESTING PIPELINE WITH TRUE RANDOM SAMPLING")
    print("=" * 60)
    
    # Load tweets with true random sampling
    print("1. Loading tweets with proportional random sampling...")
    sample_tweets = load_all_tweets_randomly(file_paths, sample_size=10)
    
    # Classify with GPT
    print("\n2. Classifying tweets with GPT-4...")
    test_data = []
    
    for i, tweet in enumerate(sample_tweets):
        print(f"   Classifying tweet {i+1}/10...")
        
        tweet_id = tweet.get('id', f'tweet_{i}')
        tweet_text = tweet.get('text', '')
        created_at = tweet.get('created_at', 'unknown')
        
        if len(tweet_text.strip()) < 10:
            continue
        
        # Classify with GPT
        classification = classify_tweet_with_gpt(tweet_text)
        
        test_data.append({
            'tweet_id': tweet_id,
            'text': tweet_text,
            'created_at': created_at,
            'label': classification['label'],
            'confidence': classification['confidence'],
            'reasoning': classification['reasoning']
        })
        
        # Rate limiting
        import time
        time.sleep(0.2)
    
    # Save test results
    print("\n3. Saving test results...")
    with open('test_results.csv', 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(['tweet_id', 'created_at', 'text', 'label', 'confidence', 'reasoning'])
        for item in test_data:
            writer.writerow([
                item['tweet_id'],
                item['created_at'],
                item['text'][:100] + "..." if len(item['text']) > 100 else item['text'],
                item['label'],
                item['confidence'],
                item['reasoning']
            ])
    
    # Print results
    print("\n4. Test Results:")
    print("=" * 60)
    for i, item in enumerate(test_data):
        print(f"Tweet {i+1}:")
        print(f"Date: {item['created_at']}")
        print(f"Text: {item['text'][:80]}...")
        print(f"Label: {item['label']} ({'Injustice' if item['label'] == 1 else 'No Injustice'})")
        print(f"Confidence: {item['confidence']:.2f}")
        print(f"Reasoning: {item['reasoning']}")
        print("-" * 40)
    
    # Summary
    injustice_count = sum(1 for item in test_data if item['label'] == 1)
    total_count = len(test_data)
    
    print(f"\n📊 SUMMARY:")
    print(f"Total tweets tested: {total_count}")
    print(f"Injustice tweets: {injustice_count}")
    print(f"No injustice tweets: {total_count - injustice_count}")
    print(f"Test results saved to: test_results.csv")
    print(f"\n✅ If this looks good, you can run the full pipeline!")
    print(f"💰 Cost for this test: ~$0.10")
    print(f"💰 Cost for full 2000 tweets: ~$20")

if __name__ == "__main__":
    test_pipeline()
