import json
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict
import numpy as np

def analyze_tweet_dates(filename="tweets-0525-0615-2-nort"):
    """
    Analyze dates in the tweets JSON file to understand the date format and distribution
    """
    print(f"Analyzing dates in {filename}...")
    print("=" * 60)
    
    # Date statistics
    date_counts = defaultdict(int)
    hour_counts = defaultdict(int)
    weekday_counts = defaultdict(int)
    all_dates = []
    total_tweets = 0
    
    # Read and process the JSON file line by line
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            # Read first line to understand structure
            first_line = f.readline()
            data = json.loads(first_line)
            
            print("DATE FORMAT EXPLANATION:")
            print("-" * 30)
            print("The tweets contain 'created_at' field with ISO 8601 format:")
            
            # Show example of date format
            if 'data' in data and len(data['data']) > 0:
                example_tweet = data['data'][0]
                example_date = example_tweet.get('created_at', '')
                print(f"Example: '{example_date}'")
                print("Format: YYYY-MM-DDTHH:MM:SS.sssZ")
                print("  - YYYY: 4-digit year")
                print("  - MM: 2-digit month (01-12)")
                print("  - DD: 2-digit day (01-31)")
                print("  - T: Date/time separator")
                print("  - HH: 2-digit hour (00-23)")
                print("  - MM: 2-digit minute (00-59)")
                print("  - SS: 2-digit second (00-59)")
                print("  - sss: 3-digit milliseconds")
                print("  - Z: UTC timezone indicator")
                print()
                
                # Parse the example date
                try:
                    parsed_date = datetime.fromisoformat(example_date.replace('Z', '+00:00'))
                    print(f"Parsed date: {parsed_date}")
                    print(f"Date only: {parsed_date.date()}")
                    print(f"Time only: {parsed_date.time()}")
                    print(f"Day of week: {parsed_date.strftime('%A')}")
                    print(f"Month name: {parsed_date.strftime('%B')}")
                    print()
                except Exception as e:
                    print(f"Error parsing date: {e}")
            
            # Reset file pointer
            f.seek(0)
            
            print("PROCESSING TWEETS FOR DATE ANALYSIS...")
            print("-" * 40)
            
            # Process each line (each line is a JSON object with multiple tweets)
            line_count = 0
            for line in f:
                line_count += 1
                if line_count % 100 == 0:
                    print(f"Processed {line_count} lines, {total_tweets} tweets...")
                
                try:
                    data = json.loads(line.strip())
                    
                    # Process tweets in this data object
                    if 'data' in data:
                        for tweet in data['data']:
                            if 'created_at' in tweet:
                                total_tweets += 1
                                date_str = tweet['created_at']
                                
                                # Parse the date
                                try:
                                    # Convert Z to +00:00 for Python datetime
                                    dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                                    
                                    # Store various date components
                                    date_only = dt.date()
                                    hour = dt.hour
                                    weekday = dt.strftime('%A')
                                    
                                    date_counts[str(date_only)] += 1
                                    hour_counts[hour] += 1
                                    weekday_counts[weekday] += 1
                                    all_dates.append(dt)
                                    
                                except Exception as e:
                                    print(f"Error parsing date {date_str}: {e}")
                
                except json.JSONDecodeError as e:
                    print(f"Error parsing JSON on line {line_count}: {e}")
                    continue
                
                # Limit processing for demo (remove this for full analysis)
                if line_count >= 20:  # Process first 20 lines for demo
                    break
    
    except FileNotFoundError:
        print(f"File {filename} not found!")
        return
    except Exception as e:
        print(f"Error reading file: {e}")
        return
    
    print(f"\nANALYSIS COMPLETE!")
    print(f"Total tweets processed: {total_tweets}")
    print(f"Date range: {min(all_dates)} to {max(all_dates)}")
    print()
    
    # Show top dates
    print("TOP 10 DATES BY TWEET COUNT:")
    print("-" * 30)
    sorted_dates = sorted(date_counts.items(), key=lambda x: x[1], reverse=True)
    for date, count in sorted_dates[:10]:
        print(f"{date}: {count} tweets")
    
    print("\nTWEETS BY HOUR OF DAY:")
    print("-" * 25)
    for hour in sorted(hour_counts.keys()):
        count = hour_counts[hour]
        bar = "█" * min(50, count // 10)  # Visual bar
        print(f"{hour:2d}:00 | {count:4d} | {bar}")
    
    print("\nTWEETS BY DAY OF WEEK:")
    print("-" * 25)
    weekday_order = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
    for day in weekday_order:
        if day in weekday_counts:
            count = weekday_counts[day]
            bar = "█" * min(30, count // 10)
            print(f"{day:9s} | {count:4d} | {bar}")

def convert_tweet_dates_to_csv(input_file="tweets-0525-0615-2-nort", output_file="tweet_dates_analysis.csv"):
    """
    Extract tweet dates and basic info to a CSV for easier analysis
    """
    print(f"Converting tweet dates from {input_file} to {output_file}...")
    
    tweets_data = []
    
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            line_count = 0
            for line in f:
                line_count += 1
                if line_count % 100 == 0:
                    print(f"Processing line {line_count}...")
                
                try:
                    data = json.loads(line.strip())
                    
                    if 'data' in data:
                        for tweet in data['data']:
                            if 'created_at' in tweet:
                                date_str = tweet['created_at']
                                try:
                                    dt = datetime.fromisoformat(date_str.replace('Z', '+00:00'))
                                    
                                    tweet_info = {
                                        'tweet_id': tweet.get('id', ''),
                                        'created_at_original': date_str,
                                        'created_at_parsed': dt,
                                        'date': dt.date(),
                                        'time': dt.time(),
                                        'hour': dt.hour,
                                        'day_of_week': dt.strftime('%A'),
                                        'month': dt.month,
                                        'year': dt.year,
                                        'text': tweet.get('text', '')[:100],  # First 100 chars
                                        'author_id': tweet.get('author_id', ''),
                                        'retweet_count': tweet.get('public_metrics', {}).get('retweet_count', 0),
                                        'like_count': tweet.get('public_metrics', {}).get('like_count', 0)
                                    }
                                    tweets_data.append(tweet_info)
                                
                                except Exception as e:
                                    print(f"Error parsing date {date_str}: {e}")
                
                except json.JSONDecodeError:
                    continue
                
                # Limit for demo
                if line_count >= 10:
                    break
    
        # Convert to DataFrame and save
        df = pd.DataFrame(tweets_data)
        df.to_csv(output_file, index=False)
        print(f"Saved {len(tweets_data)} tweets to {output_file}")
        
        # Show sample
        print("\nSAMPLE DATA:")
        print(df[['date', 'time', 'hour', 'day_of_week', 'text']].head())
        
    except Exception as e:
        print(f"Error: {e}")

def working_with_dates_examples():
    """
    Show examples of how to work with the tweet dates in Python
    """
    print("PYTHON CODE EXAMPLES FOR WORKING WITH TWEET DATES:")
    print("=" * 55)
    
    examples = [
        ("Parse ISO 8601 date string", '''
from datetime import datetime

date_string = "2020-06-05T19:37:45.000Z"
# Convert Z to +00:00 for Python
parsed_date = datetime.fromisoformat(date_string.replace('Z', '+00:00'))
print(f"Parsed: {parsed_date}")
print(f"Date only: {parsed_date.date()}")
print(f"Hour: {parsed_date.hour}")
'''),
        
        ("Filter tweets by date range", '''
import pandas as pd
from datetime import datetime, date

# Assuming you have a DataFrame with parsed dates
start_date = date(2020, 6, 1)
end_date = date(2020, 6, 10)

# Filter tweets
filtered_tweets = df[
    (df['date'] >= start_date) & 
    (df['date'] <= end_date)
]
'''),
        
        ("Group tweets by date", '''
# Count tweets per day
daily_counts = df.groupby('date').size()
print(daily_counts)

# Count tweets per hour
hourly_counts = df.groupby('hour').size()
print(hourly_counts)
'''),
        
        ("Convert to different timezones", '''
import pytz

# Convert UTC to Eastern Time
eastern = pytz.timezone('US/Eastern')
df['created_at_eastern'] = df['created_at_parsed'].dt.tz_convert(eastern)
''')
    ]
    
    for title, code in examples:
        print(f"\n{title}:")
        print("-" * len(title))
        print(code)

if __name__ == "__main__":
    print("TWEET DATE ANALYSIS TOOL")
    print("=" * 50)
    
    # Analyze the tweet dates
    analyze_tweet_dates()
    
    print("\n" + "=" * 50)
    
    # Convert some data to CSV for easier analysis
    convert_tweet_dates_to_csv()
    
    print("\n" + "=" * 50)
    
    # Show code examples
    working_with_dates_examples() 