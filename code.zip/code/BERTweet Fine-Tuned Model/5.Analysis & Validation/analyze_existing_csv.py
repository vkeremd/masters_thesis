import pandas as pd
import numpy as np
import re
from collections import defaultdict
import csv

def is_pro_blm(text):
    """Check if tweet text is pro-BLM"""
    if pd.isna(text):
        return False
    
    # Pro-BLM indicators
    pro_indicators = [
        "black lives matter", "blm", "justice for", "say their names",
        "defund the police", "abolish the police", "systemic racism",
        "police brutality", "racial justice", "protest", "march",
        "solidarity", "stand with", "support blm", "george floyd",
        "breonna taylor", "ahmaud arbery"
    ]
    
    # Anti-BLM indicators
    anti_indicators = [
        "all lives matter", "blue lives matter", "riots", "looters",
        "thugs", "criminals", "antifa", "violent protests",
        "law and order", "back the blue"
    ]
    
    text_lower = str(text).lower()
    
    # Check for pro-BLM indicators
    pro_score = sum(1 for indicator in pro_indicators if indicator in text_lower)
    
    # Check for anti-BLM indicators
    anti_score = sum(1 for indicator in anti_indicators if indicator in text_lower)
    
    # If there are more pro indicators than anti, classify as pro-BLM
    return pro_score > anti_score

def analyze_csv_by_location():
    print("Analyzing tweet_analysis_results.csv for BLM content by location...")
    
    chunk_size = 10000
    location_stats = defaultdict(lambda: {"total": 0, "pro_blm": 0, "anti_blm": 0})
    total_processed = 0
    blm_related_count = 0
    
    try:
        for chunk in pd.read_csv("tweet_analysis_results.csv", chunksize=chunk_size, 
                                dtype={'user_location': 'str'}, 
                                on_bad_lines='skip'):
            
            for idx, row in chunk.iterrows():
                total_processed += 1
                
                if total_processed % 50000 == 0:
                    print(f"Processed {total_processed} tweets...")
                
                text = row.get('text', '')
                location = row.get('user_location', '')
                
                # Skip if no location or text
                if pd.isna(location) or location == 'nan' or not location:
                    continue
                
                # Check if tweet contains BLM-related content
                text_lower = str(text).lower()
                blm_keywords = ['black lives matter', 'blm', 'george floyd', 'police brutality', 
                              'systemic racism', 'racial justice', 'defund police', 'say their names',
                              'breonna taylor', 'ahmaud arbery', 'all lives matter', 'blue lives matter']
                
                if any(keyword in text_lower for keyword in blm_keywords):
                    blm_related_count += 1
                    location_stats[location]["total"] += 1
                    
                    if is_pro_blm(text):
                        location_stats[location]["pro_blm"] += 1
                    else:
                        location_stats[location]["anti_blm"] += 1
    
    except Exception as e:
        print(f"Error processing CSV: {str(e)}")
        print(f"Processed {total_processed} tweets so far")
    
    print(f"\nAnalysis complete!")
    print(f"Total tweets processed: {total_processed}")
    print(f"BLM-related tweets found: {blm_related_count}")
    print(f"Unique locations with BLM tweets: {len(location_stats)}")
    
    # Save results to CSV
    output_file = "blm_tweets_by_location_from_existing.csv"
    with open(output_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['location', 'total_tweets', 'pro_blm_tweets', 'anti_blm_tweets', 'pro_blm_percentage'])
        
        for location, stats in sorted(location_stats.items(), key=lambda x: x[1]["total"], reverse=True):
            total = stats["total"]
            pro_blm = stats["pro_blm"]
            anti_blm = stats["anti_blm"]
            pro_blm_pct = (pro_blm / total * 100) if total > 0 else 0
            
            writer.writerow([location, total, pro_blm, anti_blm, round(pro_blm_pct, 2)])
    
    print(f"Results saved to: {output_file}")
    
    # Show top 20 locations
    print(f"\nTop 20 locations by BLM tweet volume:")
    print("-" * 60)
    top_locations = sorted(location_stats.items(), key=lambda x: x[1]["total"], reverse=True)[:20]
    for location, stats in top_locations:
        print(f"{location}: {stats['total']} tweets ({stats['pro_blm']} pro-BLM, {stats['anti_blm']} anti-BLM)")

if __name__ == "__main__":
    analyze_csv_by_location() 